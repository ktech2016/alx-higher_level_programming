#!/usr/bin/python3
def magic_string(l=[]):
    l += ["Holberton"]
    return ", ".join(l)
